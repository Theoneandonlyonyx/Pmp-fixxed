package net.mikexxx.pmpport;

import net.minecraft.world.level.block.LeavesBlock;

/**
 * Leaves like vanilla, but "persistent" is the default state: leaves placed by a player, with WorldEdit, from the
 * creative inventory or by any command never decay. Only leaves grown by TreeGen (sapling / bone meal) are created
 * non-persistent, so they decay (and drop saplings / fruit) once no log is within range.
 */
public class PmpLeavesBlock extends LeavesBlock {
    public PmpLeavesBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.defaultBlockState().setValue(PERSISTENT, true));
    }
}
